<!DOCTYPE html>

<html data-fr-theme="" lang="fr">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta charset="utf-8"/>
    <meta name="title" content="Les archives des résultats des élections en France"/>
    <meta name="description"
          content="Retrouvez toutes les informations concernant les résultats des élections en France."/>
    <meta name="keywords"
          content="élections, élection france, élection , résultats élection, résultats élections, résultat élection, candidats élection, candidats elections, candidatures élection , scrutin elections"/>
    <meta name="author" content="Ministère de l'Intérieur et des Outre-mer"/>
    <meta name="copyright" content="Ministère de l'Intérieur et des Outre-mer"/>
    <meta name="robots" content="index,follow"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title>Les archives des élections en France</title>
    <link rel="stylesheet" type="text/css" href="/assets/css/carte.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/sie2.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/style.css" />
    <!-- dsfr -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <link rel="stylesheet" href="/assets/dsfr/1.9.2/dist/dsfr/dsfr.min.css"/>

    <link rel="stylesheet" media="all" href="/assets/dsfr/1.9.2/dist/utility/utility.main.min.css"/>
    <link rel="stylesheet" media="all" href="/assets/dsfr/1.9.2/dist/utility/colors/colors.min.css"/>
    <meta name="theme-color" content="#000091"/>
    <!-- Défini la couleur de thème du navigateur (Safari/Android) -->
    <link rel="apple-touch-icon" href="/assets/dsfr/1.9.2/dist/favicon/favicon/apple-touch-icon.png"/>
    <!-- 180×180 -->
    <link rel="icon" href="/assets/dsfr/1.9.2/dist/favicon//favicon.svg" type="image/svg+xml"/>
    <link rel="shortcut icon" href="/assets/dsfr/1.9.2/dist/favicon//favicon.ico" type="image/x-icon"/>
    <!-- 32×32 -->
    <link rel="manifest" href="/assets/dsfr/1.9.2/dist/favicon/manifest.webmanifest"
          crossorigin="use-credentials"/>
</head><body>
<header role="banner" class="fr-header">
    <div class="fr-header__body">
        <div class="fr-container">
            <div class="fr-header__body-row">
                <div class="fr-header__brand fr-enlarge-link">
                    <div class="fr-header__brand-top">
                        <div class="fr-header__logo">
                            <a href="/" title="Accueil - Les archives des résultats des élections en France">
                                <p class="fr-logo">
                                    Ministère<br>
                                    de l'Intérieur
                                </p>
                            </a>
                        </div>
                        <div class="fr-header__navbar">
                            <button class="fr-btn--search fr-btn" data-fr-opened="false" aria-controls="modal-824"
                                    id="button-825"
                                    title="Rechercher">
                                Rechercher
                            </button>
                            <button class="fr-btn--menu fr-btn" data-fr-opened="false" aria-controls="modal-828"
                                    aria-haspopup="menu"
                                    id="button-829" title="Menu">
                                Menu
                            </button>
                        </div>
                    </div>
                    <div class="fr-header__service">
                        <a href="/" title="Accueil - Les archives des résultats des élections en France">
                            <p class="fr-header__service-title">Les élections en France</p>
                        </a>
                    </div>
                </div>

                <div class="fr-header__tools">
                    <div class="fr-header__tools-links">
                        <ul class="fr-btns-group">

                            <li>
                                <button class="fr-btn fr-icon-theme-fill fr-btn--icon-left fr-ml-2v"
                                        aria-controls="fr-theme-modal"
                                        data-fr-opened="false" title="Paramètres d'affichage"
                                        id="button-display-settings">Paramètres
                                    d'affichage
                                </button>
                            </li>
                        </ul>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="fr-header__menu fr-modal" id="modal-828" aria-labelledby="button-829">
        <div class="fr-container">
            <button class="fr-btn--close fr-btn" aria-controls="modal-828" title="Fermer">Fermer</button>
            <div class="fr-header__menu-links"></div>
            <nav class="fr-nav" id="navigation-804" role="navigation" aria-label="Menu principal">


                <ul class="fr-nav__list">
                    <li class="fr-nav__item">
                        <button class="fr-nav__btn" aria-expanded="false" aria-controls="menu-1">Comprendre les
                            élections
                        </button>
                        <div class="fr-collapse fr-menu" id="menu-1">
                            <ul class="fr-menu__list">
                                <ul>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comprendre-elections"
                                           class="fr-nav__link">Toutes
                                            les questions</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comprendre-elections/comment-je-vote"
                                           class="fr-nav__link">Comment je vote ?</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comprendre-elections/pourquoi-je-vote"
                                           class="fr-nav__link">Pourquoi je vote ?</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comprendre-elections/pour-qui-je-vote"
                                           class="fr-nav__link">Pour qui je vote ?</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comprendre-elections/comment-sont-encadrees-campagnes-electorales"
                                           class="fr-nav__link">Comment sont encadrées les campagnes électorales?</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comprendre-elections/qui-organise-elections"
                                           class="fr-nav__link">Qui organise les élections ?</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/comment-voter"
                                           class="fr-nav__link">Foire aux
                                            questions</a>
                                    </li>
                                </ul>

                            </ul>
                        </div>
                    </li>
                    <li class="fr-nav__item">
                        <button class="fr-nav__btn" aria-expanded="false" aria-controls="menu-2">Mes démarches</button>
                        <div class="fr-collapse fr-menu" id="menu-2">
                            <ul class="fr-menu__list">
                                <ul>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches"
                                           class="fr-nav__link">Toutes mes
                                            démarches électorales</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches/je-verifie-ma-situation-electorale"
                                           class="fr-nav__link">Je vérifie ma situation électorale</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches/je-trouve-mon-bureau-de-vote"
                                           class="fr-nav__link">Je trouve mon bureau de vote</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches/je-donne-procuration"
                                           class="fr-nav__link">Je donne procuration</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches/procuration-je-trouve-mon-numero-national-delecteur"
                                           class="fr-nav__link">Procuration : je trouve mon numéro national d&#039;électeur</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches/je-verifie-a-qui-jai-donne-procuration-ou-qui-ma-donne-procuration"
                                           class="fr-nav__link">Je vérifie à qui j&#039;ai donné procuration ou qui m&#039;a
                                            donné
                                            procuration</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/mes-demarches/je-minscris-sur-listes-electorales"
                                           class="fr-nav__link">Je m&#039;inscris sur les listes électorales</a>
                                    </li>
                                </ul>

                            </ul>
                        </div>
                    </li>
                    <li class="fr-nav__item">
                        <button class="fr-nav__btn" aria-expanded="false" aria-controls="menu-3">Les scrutins</button>
                        <div class="fr-collapse fr-menu" id="menu-3">
                            <ul class="fr-menu__list">
                                <ul>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins" class="fr-nav__link">Tous
                                            les
                                            scrutins</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/lelection-presidentielle"
                                           class="fr-nav__link">L&#039;élection présidentielle</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/elections-legislatives"
                                           class="fr-nav__link">Les élections législatives</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/elections-senatoriales"
                                           class="fr-nav__link">Les élections sénatoriales</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/elections-europeennes"
                                           class="fr-nav__link">Les élections européennes</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/elections-regionales"
                                           class="fr-nav__link">Les élections régionales</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/elections-departementales"
                                           class="fr-nav__link">Les élections départementales</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/elections-municipales-et-communautaires"
                                           class="fr-nav__link">Les élections municipales et communautaires</a>
                                    </li>
                                    <li class="fr-nav__item">
                                        <a href="https://www.elections.interieur.gouv.fr/scrutins/consultations"
                                           class="fr-nav__link">Les
                                            consultations</a>
                                    </li>
                                </ul>

                            </ul>
                        </div>
                    </li>
                    <li class="fr-nav__item">
                        <button class="fr-nav__btn" aria-expanded="false" aria-controls="menu-4">Les résultats</button>
                        <div class="fr-collapse fr-menu" id="menu-4">
                            <ul class="fr-menu__list">
                                <ul>
                                    <li class="fr-nav__item">
                                        <a href="https://www.resultats-elections.interieur.gouv.fr/"
                                           class="fr-nav__link">Les résultats en direct</a>
                                    </li>
<!--                                    <li class="fr-nav__item">-->
<!--                                        <a href="https://www.elections.interieur.gouv.fr/resultats/resultats-de-toutes-elections"-->
<!--                                           class="fr-nav__link">Les résultats de toutes les élections</a>-->
<!--                                    </li>-->
                                </ul>
                            </ul>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

</header>
<main>
<div class="fr-container fr-mt-4v fr-mb-4v">
<div class="container pub-enveloppe" id="top">
<p>10 et 24 avril 2022</p>
<div><img alt="Election présidentielle 2022" src="../../img/pr2022.jpg" title="Election présidentielle 2022" width="100"/></div>
<div class="pub-contenu">
<div class="container pub-corps text-center">
<div class="row-fluid pub-fil-ariane"><div class="span12 pub-fil-ariane">
<a href="../../index.php">Accueil Présidentielle 2022</a> &gt; <a href="../../011/011.php">Île-de-France</a> &gt; <a href="../../011/075/index.php">Paris (75)</a>
</div></div>
<div class="offset2 span8">
<h3>Résultats par arrondissement :</h3>
<p><i>Cliquez sur le numéro de votre arrondissement</i></p>
<a href="../../011/075/075056AR01.php">1er</a> <a href="../../011/075/075056AR02.php">2ème</a> <a href="../../011/075/075056AR03.php">3ème</a> <a href="../../011/075/075056AR04.php">4ème</a> <a href="../../011/075/075056AR05.php">5ème</a> <a href="../../011/075/075056AR06.php">6ème</a> <a href="../../011/075/075056AR07.php">7ème</a> <a href="../../011/075/075056AR08.php">8ème</a> <a href="../../011/075/075056AR09.php">9ème</a> <a href="../../011/075/075056AR10.php">10ème</a> <a href="../../011/075/075056AR11.php">11ème</a> <a href="../../011/075/075056AR12.php">12ème</a> <a href="../../011/075/075056AR13.php">13ème</a> <a href="../../011/075/075056AR14.php">14ème</a> <a href="../../011/075/075056AR15.php">15ème</a> <a href="../../011/075/075056AR16.php">16ème</a> <a href="../../011/075/075056AR17.php">17ème</a> <a href="../../011/075/075056AR18.php">18ème</a> <a href="../../011/075/075056AR19.php">19ème</a> <a href="../../011/075/075056AR20.php">20ème</a> <hr/>
</div>
<div class="row-fluid pub-resultats-entete"><div class="offset2 span8">
<h3>
<sup>*</sup>
					Résultats
					 du département 		
					au 2<sup>d</sup> tour
				</h3>
<table class="fr-table">
<thead><tr>
<th>Liste des candidats </th>
<th>Voix</th>
<th>% Inscrits</th>
<th>% Exprimés</th>
</tr></thead>
<tbody>
<tr>
<td>M. Emmanuel MACRON</td>
<td>808 107</td>
<td>  59,05</td>
<td>  85,11</td>
</tr>
<tr>
<td>Mme Marine LE PEN</td>
<td>141 405</td>
<td>  10,33</td>
<td>  14,89</td>
</tr>
</tbody>
</table>
<br/><br/><table class="fr-table">
<thead><tr>
<th></th>
<th>Nombre</th>
<th>% Inscrits</th>
<th>% Votants</th>
</tr></thead>
<tbody>
<tr>
<td>Inscrits</td>
<td>1 368 623</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Abstentions</td>
<td>354 494</td>
<td>  25,90</td>
<td></td>
</tr>
<tr>
<td>Votants</td>
<td>1 014 129</td>
<td>  74,10</td>
<td></td>
</tr>
<tr>
<td>Blancs</td>
<td>49 446</td>
<td>   3,61</td>
<td>   4,88</td>
</tr>
<tr>
<td>Nuls</td>
<td>15 171</td>
<td>   1,11</td>
<td>   1,50</td>
</tr>
<tr>
<td>Exprimés</td>
<td>949 512</td>
<td>  69,38</td>
<td>  93,63</td>
</tr>
</tbody>
</table>
<br/>En raison des arrondis à la deuxième décimale, la somme des pourcentages peut ne pas être égale à 100%.<h3>
<sup>*</sup>Rappel des 
					Résultats
					 du département 
					au 1<sup>er</sup> tour
				</h3>
<table class="fr-table">
<thead><tr>
<th>Liste des candidats </th>
<th>Voix</th>
<th>% Inscrits</th>
<th>% Exprimés</th>
</tr></thead>
<tbody>
<tr>
<td>M. Emmanuel MACRON</td>
<td>372 820</td>
<td>  27,25</td>
<td>  35,34</td>
</tr>
<tr>
<td>M. Jean-Luc MÉLENCHON</td>
<td>317 372</td>
<td>  23,20</td>
<td>  30,08</td>
</tr>
<tr>
<td>M. Éric ZEMMOUR</td>
<td>86 088</td>
<td>   6,29</td>
<td>   8,16</td>
</tr>
<tr>
<td>M. Yannick JADOT</td>
<td>80 268</td>
<td>   5,87</td>
<td>   7,61</td>
</tr>
<tr>
<td>Mme Valérie PÉCRESSE</td>
<td>69 564</td>
<td>   5,08</td>
<td>   6,59</td>
</tr>
<tr>
<td>Mme Marine LE PEN</td>
<td>58 429</td>
<td>   4,27</td>
<td>   5,54</td>
</tr>
<tr>
<td>Mme Anne HIDALGO</td>
<td>22 901</td>
<td>   1,67</td>
<td>   2,17</td>
</tr>
<tr>
<td>M. Fabien ROUSSEL</td>
<td>17 267</td>
<td>   1,26</td>
<td>   1,64</td>
</tr>
<tr>
<td>M. Jean LASSALLE</td>
<td>12 139</td>
<td>   0,89</td>
<td>   1,15</td>
</tr>
<tr>
<td>M. Nicolas DUPONT-AIGNAN</td>
<td>9 591</td>
<td>   0,70</td>
<td>   0,91</td>
</tr>
<tr>
<td>M. Philippe POUTOU</td>
<td>5 732</td>
<td>   0,42</td>
<td>   0,54</td>
</tr>
<tr>
<td>Mme Nathalie ARTHAUD</td>
<td>2 891</td>
<td>   0,21</td>
<td>   0,27</td>
</tr>
</tbody>
</table>
<br/><br/><table class="fr-table">
<thead><tr>
<th></th>
<th>Nombre</th>
<th>% Inscrits</th>
<th>% Votants</th>
</tr></thead>
<tbody>
<tr>
<td>Inscrits</td>
<td>1 368 025</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Abstentions</td>
<td>296 668</td>
<td>  21,69</td>
<td></td>
</tr>
<tr>
<td>Votants</td>
<td>1 071 357</td>
<td>  78,31</td>
<td></td>
</tr>
<tr>
<td>Blancs</td>
<td>11 028</td>
<td>   0,81</td>
<td>   1,03</td>
</tr>
<tr>
<td>Nuls</td>
<td>5 267</td>
<td>   0,39</td>
<td>   0,49</td>
</tr>
<tr>
<td>Exprimés</td>
<td>1 055 062</td>
<td>  77,12</td>
<td>  98,48</td>
</tr>
</tbody>
</table>
<br/>En raison des arrondis à la deuxième décimale, la somme des pourcentages peut ne pas être égale à 100%.<br/><br/><div class="span7 text-left">*Résultats proclamés par le Conseil Constitutionnel.</div>
</div></div>
</div>
<div class="pub-bas"><div class="span7 text-right">
										 
										 
										<a href="#top">Haut de page</a>
</div></div>
</div>
</div>
</div>
</main>
<div id="block-reseauxsociaux">
     <div>
          <div>
               <div class="fr-follow">
                    <div class="fr-container">
                         <div class="fr-grid-row">
                              <div class="fr-col-12">
                                   <div class="fr-follow__social">
                                        <div class="fr-h5 fr-mb-3v fr-mb-3v">
                                             <div>Suivez-nous sur nos réseaux sociaux</div>
                                        </div>
                                        <ul class="fr-links-group fr-links-group--lg">
                                             <li>
                                                  <div>
                                                       <a href="https://www.facebook.com/Interieur.Gouv/"
                                                            class="fr-link fr-link--facebook"
                                                            target="_blank">Facebook</a>
                                                  </div>
                                             </li>
                                             <li>
                                                  <div>
                                                       <a href="https://twitter.com/Interieur_Gouv"
                                                            class="fr-link fr-link--twitter" target="_blank">Twitter</a>
                                                  </div>
                                             </li>
                                             <li>
                                                  <div>
                                                       <a href="https://www.instagram.com/interieur_gouv"
                                                            class="fr-link fr-link--instagram"
                                                            target="_blank">Instagram</a>
                                                  </div>
                                             </li>
                                             <li>
                                                  <div>
                                                       <a href="https://fr.linkedin.com/company/ministere-de-l-interieur"
                                                            class="fr-link fr-link--linkedin"
                                                            target="_blank">LinkedIn</a>
                                                  </div>
                                             </li>
                                             <li>
                                                  <div>
                                                       <a href="https://www.youtube.com/user/MinistereInterieur"
                                                            class="fr-link fr-link--youtube" target="_blank">YouTube</a>
                                                  </div>
                                             </li>
                                        </ul>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </div>
</div>    <footer class="fr-footer" role="contentinfo" id="footer-614">
      <div class="fr-container">
        <div class="fr-footer__body">
          <div class="fr-footer__brand fr-enlarge-link">
            <div id="block-elections-blocmarquefooter-2">
              <div>
                <a href="/" title="Ministère de l'intérieur">
                  <p class="fr-logo">
                    Ministère
                    <br />de l'intérieur
                  </p>
                </a>
              </div>
            </div>
          </div>
          <div class="fr-footer__content">
            <nav
              role="navigation"
              aria-labelledby="block-elections-sitesexternes-2-menu"
              id="block-elections-sitesexternes-2"
            >
              <ul class="fr-footer__content-list">
                <li class="fr-footer__content-item&quot;">
                  <a
                    href="https://legifrance.gouv.fr/"
                    class="fr-footer__content-link"
                    >legifrance.gouv.fr</a
                  >
                </li>
                <li class="fr-footer__content-item&quot;">
                  <a
                    href="https://gouvernement.fr/"
                    class="fr-footer__content-link"
                    target="_blank"
                    rel="noopener noreferrer"
                    >gouvernement.fr</a
                  >
                </li>
                <li class="fr-footer__content-item&quot;">
                  <a
                    href="https://data.gouv.fr/"
                    class="fr-footer__content-link"
                    >data.gouv.fr</a
                  >
                </li>
                <li class="fr-footer__content-item&quot;">
                  <a
                    href="https://service-public.fr/"
                    class="fr-footer__content-link"
                    target="_blank"
                    rel="noopener noreferrer"
                    >service-public.fr</a
                  >
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <div class="fr-footer__bottom">
          <nav
            role="navigation"
            aria-labelledby="block-elections-pieddepage-menu"
            id="block-elections-pieddepage"
            class="fr-footer__bottom-list fr-pb-2v"
          >
            <ul class="fr-footer__bottom-list">
              <li class="fr-footer__bottom-item">
                <a
                  href="https://www.elections.interieur.gouv.fr/declaration-daccessibilite"
                  class="fr-footer__bottom-link"
                  data-drupal-link-system-path="node/61"
                  >Accessibilité : partiellement conforme</a
                >
              </li>
              <li class="fr-footer__bottom-item">
                <a
                  href="https://www.elections.interieur.gouv.fr/mentions-legales"
                  class="fr-footer__bottom-link"
                  data-drupal-link-system-path="node/60"
                  >Mentions légales</a
                >
              </li>
              <li class="fr-footer__bottom-item">
                <a
                  href="https://www.elections.interieur.gouv.fr/politique-de-confidentialite"
                  class="fr-footer__bottom-link"
                  data-drupal-link-system-path="node/64"
                  >Politique de confidentialité</a
                >
              </li>
            </ul>
          </nav>
          <div id="block-elections-licenceetalab">
            <div>
              <div class="fr-footer__bottom-copy">
                <p>
                  <span
                    >Sauf mention contraire, tous les contenus de ce site sont
                    sous </span
                  ><a
                    href="https://github.com/etalab/licence-ouverte/blob/master/LO.md"
                    rel="noopener noreferrer"
                    target="_blank"
                    title="licence etalab-2.0 - nouvelle fenêtre"
                    >licence etalab-2.0</a
                  >
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>

    <dialog id="fr-theme-modal" class="fr-modal" role="dialog" aria-labelledby="fr-theme-modal-title">
      <div class="fr-container fr-container--fluid fr-container-md">
        <div class="fr-grid-row fr-grid-row--center">
          <div class="fr-col-12 fr-col-md-6 fr-col-lg-4">
            <div class="fr-modal__body">
              <div class="fr-modal__header">
                <button class="fr-btn--close fr-btn" aria-controls="fr-theme-modal" id="button-5625" title="Fermer">
                  Fermer
                </button>
              </div>
              <div class="fr-modal__content">
                <h1 id="fr-theme-modal-title" class="fr-modal__title">
                  Paramètres d’affichage
                </h1>
                <div id="fr-display" class="fr-display">
                  <fieldset class="fr-fieldset" id="display-fieldset">
                    <legend class="fr-fieldset__legend--regular fr-fieldset__legend" id="display-fieldset-legend">
                      Choisissez un thème pour personnaliser l’apparence du site.
                    </legend>
                    <div class="fr-fieldset__element">
                      <div class="fr-radio-group fr-radio-rich">
                        <input value="light" type="radio" id="fr-radios-theme-light" name="fr-radios-theme">
                        <label class="fr-label" for="fr-radios-theme-light">
                          Thème clair
                        </label>
                        <div class="fr-radio-rich__img">
                          <svg aria-hidden="true" class="fr-artwork" viewBox="0 0 80 80" width="80px" height="80px">
                            <use class="fr-artwork-decorative"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/environment/sun.svg#artwork-decorative"></use>
                            <use class="fr-artwork-minor"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/environment/sun.svg#artwork-minor"></use>
                            <use class="fr-artwork-major"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/environment/sun.svg#artwork-major"></use>
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div class="fr-fieldset__element">
                      <div class="fr-radio-group fr-radio-rich">
                        <input value="dark" type="radio" id="fr-radios-theme-dark" name="fr-radios-theme">
                        <label class="fr-label" for="fr-radios-theme-dark">
                          Thème sombre
                        </label>
                        <div class="fr-radio-rich__img">
                          <svg aria-hidden="true" class="fr-artwork" viewBox="0 0 80 80" width="80px" height="80px">
                            <use class="fr-artwork-decorative"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/environment/moon.svg#artwork-decorative"></use>
                            <use class="fr-artwork-minor"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/environment/moon.svg#artwork-minor"></use>
                            <use class="fr-artwork-major"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/environment/moon.svg#artwork-major"></use>
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div class="fr-fieldset__element">
                      <div class="fr-radio-group fr-radio-rich">
                        <input value="system" type="radio" id="fr-radios-theme-system" name="fr-radios-theme">
                        <label class="fr-label" for="fr-radios-theme-system">
                          Système
                          <span class="fr-hint-text">Utilise les paramètres système</span>
                        </label>
                        <div class="fr-radio-rich__img">
                          <svg aria-hidden="true" class="fr-artwork" viewBox="0 0 80 80" width="80px" height="80px">
                            <use class="fr-artwork-decorative"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/system/system.svg#artwork-decorative"></use>
                              string(18) "/assets/dsfr/1.9.2"
                            <use class="fr-artwork-minor"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/system/system.svg#artwork-minor"></use>
                            <use class="fr-artwork-major"
                              href="/assets/dsfr/1.9.2/dist/artwork/pictograms/system/system.svg#artwork-major"></use>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </fieldset>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </dialog>

    <!-- script -->
    <script src="/assets/dsfr/1.9.2/dist/dsfr/dsfr.module.js"></script>
    <script type="text/javascript" nomodule src="/assets/dsfr/1.9.2/dist/dsfr/dsfr.nomodule.min.js"
    ></script>
<script>(function(){function c(){var b=a.contentDocument||(a.contentWindow&&a.contentWindow.document);if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'a3eff0e9983d99c9',t:'MTc5MDA2NTc1Nw=='};var a=document.createElement('script');a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>